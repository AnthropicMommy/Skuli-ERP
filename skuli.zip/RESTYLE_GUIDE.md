# Skuli — Component Restyle Guide & Before/After Notes

> **For OpenCode integration.** This document specifies how to restyle existing in-app components (dashboard cards, tables, forms, report card view, Mwalimu chat widget) to match the Skuli design system. It also includes before/after notes per homepage section explaining what changed and why.

---

## 1. Design Token Reference

All tokens are defined as CSS variables in `client/src/index.css` under `:root` / `.dark`. Tailwind utilities map automatically via the `@theme inline` block.

| Token | Dark Value | Usage |
|---|---|---|
| `--background` | `#0A0A0A` | Page background |
| `--surface` | `#111111` | Cards, panels |
| `--surface-hover` | `#1A1A1A` | Hover state on cards/rows |
| `--border` | `rgba(255,255,255,0.08)` | Hairline borders everywhere |
| `--border-strong` | `rgba(255,255,255,0.18)` | Focus states, active borders |
| `--text-primary` | `#FAFAFA` | Headlines, primary content |
| `--text-secondary` | `rgba(255,255,255,0.65)` | Body copy, descriptions |
| `--text-tertiary` | `rgba(255,255,255,0.40)` | Captions, timestamps, placeholders |
| `--primary` | `#7DD3FC` | Primary CTAs, active states, key highlights |
| `--primary-foreground` | `#0A0A0A` | Text on primary-colored elements |
| `--success` | `#3B9B6E` | Delivered/success status |
| `--destructive` | `#B85450` | Errors, locked/blocked states |
| `--radius` | `0.625rem (10px)` | Cards, buttons |

**Golden rule:** Never introduce a second bright color. Status colors are desaturated and quiet. The accent (`#7DD3FC`) appears on only the most important interactive element per screen.

---

## 2. Component Restyle Specs

### 2.1 Dashboard Cards

**Current state (assumed):** White or light-gray backgrounds with box-shadows, rounded corners, colored icon backgrounds.

**Target state:**

| Property | Value |
|---|---|
| Background | `var(--surface)` (`#111111`) |
| Border | `1px solid var(--border)` (hairline) |
| Border-radius | `10px` (`rounded-lg`) |
| Box-shadow | **None** — borders define edges, not shadows |
| Padding | `24px` (`p-6`) |
| Hover | `background: var(--surface-hover)`, `border-color: var(--border-strong)` |
| Title | `16px, font-weight 500, color: var(--text-primary)` |
| Description | `14px, font-weight 400, color: var(--text-secondary)` |
| Icon container | `40x40px, border: 1px solid var(--border), background: var(--background)` |
| Icon color | `var(--text-secondary)` — never accent unless it's the primary CTA |

**Tailwind classes to apply:**
```tsx
<div className="rounded-lg border border-border bg-[var(--surface)] p-6 transition-colors hover:bg-[var(--surface-hover)] hover:border-[var(--border-strong)]">
```

### 2.2 Tables (Attendance, Grades, Student Lists)

**Current state (assumed):** White background, alternating row stripes, thick borders, colored headers.

**Target state:**

| Property | Value |
|---|---|
| Container | `rounded-lg border border-border overflow-hidden` |
| Header row | `background: var(--background)`, `text: var(--text-tertiary)`, `font-size: 12px`, `text-transform: uppercase`, `letter-spacing: 0.05em` |
| Body rows | `background: var(--surface)`, `border-bottom: 1px solid var(--border)` |
| Row hover | `background: var(--surface-hover)` |
| Cell text | `14px, color: var(--text-secondary)` |
| Primary cell (name/ID) | `color: var(--text-primary), font-weight: 500` |
| Status badges | Desaturated — `bg-[var(--success)]/10 text-[var(--success)]` or `bg-[var(--destructive)]/10 text-[var(--destructive)]` |
| No alternating stripes | Use hairline borders between rows instead |

**Tailwind classes for table header:**
```tsx
<th className="text-xs uppercase tracking-wider text-[var(--text-tertiary)] font-medium px-4 py-3 bg-background border-b border-border">
```

### 2.3 Forms (Login, Data Entry, Settings)

**Current state (assumed):** Light inputs with focus rings, large padding, colored labels.

**Target state:**

| Property | Value |
|---|---|
| Input background | `var(--background)` (`#0A0A0A`) |
| Input border | `1px solid var(--border)` |
| Input border-radius | `10px` |
| Input padding | `12px 16px` (`px-4 py-3`) |
| Focus state | `border-color: var(--border-strong)`, `ring: 2px var(--primary) at 20% opacity` |
| Label | `14px, font-weight: 500, color: var(--text-primary), margin-bottom: 8px` |
| Helper text | `12px, color: var(--text-tertiary)` |
| Error text | `12px, color: var(--destructive)` |
| Submit button | `bg-primary text-primary-foreground` — the accent moment |

**Tailwind classes for input:**
```tsx
<input className="w-full rounded-lg border border-border bg-background px-4 py-3 text-sm text-[var(--text-primary)] placeholder:text-[var(--text-tertiary)] focus:border-[var(--border-strong)] focus:outline-none focus:ring-2 focus:ring-primary/20 transition-colors" />
```

### 2.4 Report Card View

**Current state (assumed):** Printable-style layout, possibly light-themed with colored grade badges.

**Target state:**

| Property | Value |
|---|---|
| Container | `rounded-xl border border-border bg-[var(--surface)] p-8` |
| Student info header | `Name: var(--text-primary) 18px font-500`, `Admission No: var(--text-tertiary) 14px` |
| Grade table | Same as table spec above |
| Grade badges | `bg-[var(--surface-hover)] text-[var(--text-primary)]` — no bright colors per grade |
| Overall grade | `text-2xl font-600 text-[var(--text-primary)]` — let typography carry the weight |
| Teacher comment | `14px, color: var(--text-secondary), font-style: normal` (no italics per design system) |
| Print button | `bg-primary text-primary-foreground` — accent moment |

### 2.5 Mwalimu Chat Widget

**Current state (assumed):** Floating chat bubble, colored header, message bubbles with different colors for user vs. AI.

**Target state:**

| Property | Value |
|---|---|
| Container | `rounded-xl border border-border bg-[var(--surface)]` |
| Header | `bg-[var(--background)] border-b border-border`, `padding: 12px 16px` |
| Header text | `14px font-500 text-[var(--text-primary)]` + `12px text-[var(--text-tertiary)]` subtitle |
| AI avatar | `32x32px rounded-lg border border-border bg-background`, icon in `var(--text-secondary)` |
| User messages | `bg-[var(--surface-hover)] text-[var(--text-primary)] rounded-lg rounded-br-sm` |
| AI messages | `bg-[var(--background)] text-[var(--text-secondary)] border border-border rounded-lg rounded-bl-sm` |
| Input bar | `bg-[var(--background)] border-t border-border`, input same as form spec |
| Send button | `bg-primary text-primary-foreground` — accent moment |
| Typing indicator | Three dots in `var(--text-tertiary)`, subtle bounce animation |
| No colored bubbles | Both user and AI use neutral surfaces; only the send button has accent color |

---

## 3. Homepage Before/After Notes

### 3.1 Header

| Aspect | Before (typical SaaS) | After (Skuli) | Why |
|---|---|---|---|
| Background | Solid white/dark bar | Transparent on load, `bg/80 + backdrop-blur` on scroll | Lets hero content breathe; precision feel when scrolling |
| Border | None or box-shadow | `1px hairline border` appears on scroll | Borders over shadows — core design principle |
| Login links | Button-styled or colored | Plain text links in `text-secondary` | Restraint — nav links shouldn't compete with CTAs |
| Mobile | Dropdown menu | Full-screen overlay with centered links | Clean, focused, no nested menus on small screens |

### 3.2 Hero

| Aspect | Before | After | Why |
|---|---|---|---|
| Layout | Centered text + button | Asymmetric: text left, 3D mockup right | Breaks the "AI slop" centered-template reflex; feels designed, not generated |
| Background | Flat color or gradient | Near-black with subtle grid pattern + radial accent glow at top | Depth without decoration; grid implies "software/precision" |
| Headline | Large, centered | 56–72px, left-aligned, tight tracking (-0.02em) | Typography carries hierarchy; left alignment feels editorial, not generic |
| CTA buttons | Multiple colored buttons | One accent CTA + one ghost/outline button | One accent per screen — the golden rule |
| Visual | Stock image or screenshot | Pure CSS/JSX dashboard mockup with 3D parallax tilt | Lightweight (no image load), interactive, on-brand |
| Motion | None or fade-in | Scroll-triggered reveal + mouse-driven 3D tilt (max 8°) + background parallax | Motion is a whisper — felt, not noticed |

### 3.3 Role Picker ("Who are you?")

| Aspect | Before | After | Why |
|---|---|---|---|
| Layout | 4 cards in a row | 2×2 grid (desktop), stacked (mobile) | Compact, dense — reads as "software," not "marketing" |
| Card style | Shadow-based, rounded | Hairline border, `bg-surface`, hover lifts background | Borders over shadows; hover is subtle, not theatrical |
| Icons | Colorful, large | Small (18px), in bordered containers, `text-secondary` | Icons are functional, not decorative |
| Accent | All cards equal | Principal card has accent CTA + "Free" badge | One accent moment per section — directs attention to the conversion path |
| CTA text | "Learn more" | Role-specific: "Log in as Student", "Book a free demo" | Specificity builds trust; tells users exactly what happens next |

### 3.4 Features

| Aspect | Before | After | Why |
|---|---|---|---|
| Layout | 3-column card grid with gaps | 3-column grid with `gap-px` — hairlines between cards, shared border | Creates a unified "panel" feel rather than floating cards |
| Card style | Individual shadow cards | Seamless grid with hairline dividers, hover changes background | Dense, compact — "premium software" density |
| Icons | Colored or gradient | Muted `text-secondary` in bordered containers | This section is intentionally quiet — no accent color |
| Descriptions | Long paragraphs | One sentence each, 14px, tight line-height | Restraint — say less, communicate more |

### 3.5 CTA Section

| Aspect | Before | After | Why |
|---|---|---|---|
| Layout | Full-width banner with gradient | Centered text with subtle radial accent glow | Quiet, not shouty; the glow is barely perceptible |
| Button | Large, pulsing or animated | Same accent button as hero — consistent | Consistency builds trust; the button is familiar by now |
| Copy | "Sign up now!" | "Ready to set up your school?" + "We handle onboarding and training. It's free." | Direct, confident, understated — no exclamation marks |

### 3.6 Footer

| Aspect | Before | After | Why |
|---|---|---|---|
| Layout | Multi-column with links | Logo + email + copyright, single row | Minimal — the footer is an endpoint, not a sales pitch |
| Border | None or shadow | `1px hairline border-top` | Consistent with the entire system |
| Color | Full text colors | `text-tertiary` for copyright — quietest level | Hierarchy extends to the very bottom |

---

## 4. Motion Implementation Notes

All motion is implemented with vanilla React hooks + CSS transitions — no heavy animation libraries required.

| Effect | Implementation | Performance |
|---|---|---|
| Scroll reveals | `IntersectionObserver` adds `.is-visible` class; CSS transitions handle opacity + translateY | Near-zero cost; observer disconnects after triggering |
| 3D hero tilt | `requestAnimationFrame` loop with lerp smoothing on `mousemove`; `perspective()` + `rotateX/Y` | GPU-accelerated transforms only; capped at 8° |
| Background parallax | `scroll` listener (passive) updates `translateY` on grid background | One `transform` update per frame; passive listener |
| Hover transitions | CSS `transition-colors` and `transition-all` via Tailwind | Native browser optimization |
| Reduced motion | All hooks check `prefers-reduced-motion` and disable effects | Accessibility-first |

**For OpenCode:** If you prefer to use Framer Motion (already in the project dependencies), the scroll reveals can be replaced with `<motion.div>` + `whileInView`. The 3D tilt can use `useMotionValue` + `useTransform`. The visual result should be identical.

---

## 5. Mobile Considerations

| Pattern | Desktop | Mobile | Rationale |
|---|---|---|---|
| Hero layout | Two-column (text + mockup) | Stacked, mockup below text | Single-column is more readable on phones |
| 3D tilt | Mouse-driven parallax | Disabled — static mockup | No mouse on touch devices; saves battery |
| Background parallax | Active | Disabled | Low-end Android performance |
| Role cards | 2×2 grid | Single column stacked | Thumb-friendly tap targets |
| Feature grid | 3-column | 1-column | Readability on narrow screens |
| Nav | Horizontal links | Full-screen overlay menu | Avoids cramped tap targets |
| Font sizes | 56–72px hero | 36–48px hero (`text-4xl sm:text-5xl`) | Readable without horizontal scroll |

---

## 6. Integration Checklist for OpenCode

- [ ] Copy CSS variables from `client/src/index.css` into the project's `globals.css` or equivalent
- [ ] Map `--primary` to the existing `--primary` token in `tailwind.config.ts` (or replace)
- [ ] Add `--surface`, `--surface-hover`, `--border-strong`, `--text-primary/secondary/tertiary` to the Tailwind theme
- [ ] Add `.eyebrow`, `.grid-bg`, `.accent-glow`, `.reveal` utility classes to globals
- [ ] Restyle dashboard cards: remove shadows, add hairline borders, use `--surface` background
- [ ] Restyle tables: remove alternating stripes, use hairline row borders, uppercase header labels
- [ ] Restyle forms: dark inputs with `--background` bg, hairline borders, accent focus ring
- [ ] Restyle report card view: monochrome grade badges, typography-led hierarchy
- [ ] Restyle Mwalimu chat: neutral message bubbles, accent only on send button
- [ ] Ensure all existing routes/pages still function — this is a restyle, not a rebuild
- [ ] Test on mobile (375px width) — all sections should stack cleanly
- [ ] Verify `prefers-reduced-motion` disables all animations
- [ ] Run Lighthouse — target 90+ performance score (no images, minimal JS)

---

*Authored by Manus AI as UX Designer for Skuli. Design system tokens, homepage template, and this restyle guide are ready for OpenCode integration.*
