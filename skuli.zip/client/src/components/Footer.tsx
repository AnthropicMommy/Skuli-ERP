import { SkuliLogo } from "./SkuliLogo";

/**
 * Skuli Footer — minimal, quiet.
 * Logo, contact email, copyright. Hairline border on top.
 */
export function Footer() {
  return (
    <footer className="border-t border-border py-12">
      <div className="container">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex flex-col items-center md:items-start gap-3">
            <SkuliLogo />
            <a
              href="mailto:info@skuli.co.ke"
              className="text-sm text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors"
            >
              info@skuli.co.ke
            </a>
          </div>
          <div className="text-sm text-[var(--text-tertiary)]">
            © 2026 Skuli
          </div>
        </div>
      </div>
    </footer>
  );
}
