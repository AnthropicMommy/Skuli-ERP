/**
 * Skuli Logo — geometric mark + wordmark.
 * A rounded square with a subtle inner notch suggesting a school building silhouette.
 * The mark uses the accent color at low opacity; the wordmark is in Geist 600.
 */

interface SkuliLogoProps {
  className?: string;
  showWordmark?: boolean;
}

export function SkuliLogo({ className = "", showWordmark = true }: SkuliLogoProps) {
  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      <svg
        width="28"
        height="28"
        viewBox="0 0 28 28"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0"
      >
        {/* Rounded square outline */}
        <rect
          x="1"
          y="1"
          width="26"
          height="26"
          rx="7"
          stroke="currentColor"
          strokeWidth="1.5"
          className="text-primary"
          opacity="0.5"
        />
        {/* Inner notch — school building silhouette */}
        <path
          d="M9 18V12.5L14 9L19 12.5V18"
          stroke="currentColor"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="text-primary"
        />
        <path
          d="M12 18V14.5H16V18"
          stroke="currentColor"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="text-primary"
        />
      </svg>
      {showWordmark && (
        <span
          className="text-[15px] font-semibold tracking-[-0.03em] text-[var(--text-primary)]"
          style={{ fontFamily: "Geist, Inter, sans-serif" }}
        >
          Skuli
        </span>
      )}
    </div>
  );
}
