/**
 * Skuli CTA Section — closing call to action.
 * Quiet, centered, with the single accent button.
 * Background has a subtle radial accent glow.
 */
export function CTASection() {
  return (
    <section className="py-24 lg:py-32 relative overflow-hidden border-t border-border">
      {/* Subtle accent glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse 60% 40% at 50% 50%, rgba(125, 211, 252, 0.04), transparent)",
        }}
      />

      <div className="container relative z-10">
        <div className="reveal max-w-2xl mx-auto text-center">
          <h2
            className="text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-[-0.02em] text-[var(--text-primary)] leading-[1.1]"
            style={{ fontFamily: "Geist, Inter, sans-serif" }}
          >
            Ready to set up your school?
          </h2>
          <p className="mt-4 text-base text-[var(--text-secondary)] leading-relaxed">
            We handle onboarding and training. It's free.
          </p>
          <div className="mt-8">
            <a
              href="#roles"
              className="inline-flex items-center justify-center h-11 px-6 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-all hover:scale-[0.98] active:scale-[0.97] accent-glow"
            >
              Book a free demo
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
