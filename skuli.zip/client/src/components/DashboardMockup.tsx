/**
 * Skuli Dashboard Mockup — a stylized in-app dashboard preview
 * used in the hero section with 3D parallax tilt.
 * Pure CSS/JSX — no images, lightweight for slow connections.
 */
export function DashboardMockup() {
  return (
    <div className="w-full h-full rounded-xl border border-border bg-[var(--surface)] overflow-hidden">
      {/* Mockup top bar */}
      <div className="flex items-center gap-2 px-4 h-10 border-b border-border">
        <div className="w-2.5 h-2.5 rounded-full bg-white/10" />
        <div className="w-2.5 h-2.5 rounded-full bg-white/10" />
        <div className="w-2.5 h-2.5 rounded-full bg-white/10" />
        <div className="ml-3 flex items-center gap-1.5">
          <div className="w-3 h-3 rounded-sm bg-primary opacity-60" />
          <span className="text-[11px] text-[var(--text-tertiary)] font-medium">skuli.co.ke / dashboard</span>
        </div>
      </div>

      {/* Mockup body */}
      <div className="p-4 flex flex-col gap-3">
        {/* Greeting row */}
        <div className="flex items-center justify-between">
          <div>
            <div className="text-[11px] text-[var(--text-tertiary)] mb-1">Good morning,</div>
            <div className="text-sm font-medium text-[var(--text-primary)]">Mr. Kamau</div>
          </div>
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full border border-border bg-[var(--surface-hover)]">
            <div className="w-1.5 h-1.5 rounded-full bg-[var(--success)]" />
            <span className="text-[10px] text-[var(--text-secondary)]">Term 2 · 2026</span>
          </div>
        </div>

        {/* Stat cards */}
        <div className="grid grid-cols-3 gap-2">
          {[
            { label: "Students", value: "1,248", change: "+12" },
            { label: "Present", value: "94.2%", change: "today" },
            { label: "Avg Grade", value: "B+", change: "Term 2" },
          ].map((stat) => (
            <div key={stat.label} className="rounded-lg border border-border bg-background p-2.5">
              <div className="text-[9px] text-[var(--text-tertiary)] uppercase tracking-wider mb-1">{stat.label}</div>
              <div className="text-sm font-semibold text-[var(--text-primary)]">{stat.value}</div>
              <div className="text-[9px] text-[var(--text-tertiary)] mt-0.5">{stat.change}</div>
            </div>
          ))}
        </div>

        {/* Attendance chart */}
        <div className="rounded-lg border border-border bg-background p-3">
          <div className="flex items-center justify-between mb-3">
            <span className="text-[10px] text-[var(--text-secondary)] font-medium">Weekly Attendance</span>
            <span className="text-[9px] text-[var(--text-tertiary)]">Mon – Fri</span>
          </div>
          <div className="flex items-end justify-between gap-1.5 h-16">
            {[88, 92, 95, 91, 97].map((h, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-1">
                <div
                  className="w-full rounded-sm bg-primary transition-all"
                  style={{ height: `${h}%`, opacity: 0.5 + (i * 0.1) }}
                />
                <span className="text-[8px] text-[var(--text-tertiary)]">{["M", "T", "W", "T", "F"][i]}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Recent activity */}
        <div className="rounded-lg border border-border bg-background p-3">
          <span className="text-[10px] text-[var(--text-secondary)] font-medium mb-2 block">Recent Activity</span>
          <div className="space-y-2">
            {[
              { text: "Form 3A attendance marked", time: "2m ago" },
              { text: "Math report card published", time: "1h ago" },
              { text: "Parent-teacher meeting scheduled", time: "3h ago" },
            ].map((item, i) => (
              <div key={i} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-1 h-1 rounded-full bg-primary" />
                  <span className="text-[10px] text-[var(--text-secondary)]">{item.text}</span>
                </div>
                <span className="text-[9px] text-[var(--text-tertiary)]">{item.time}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
