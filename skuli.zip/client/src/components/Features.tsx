import { Users, ClipboardCheck, Bot, MessageSquare, CalendarCheck, Calendar } from "lucide-react";

/**
 * Skuli Features — "Everything you need to run a school."
 * Six feature cards in a 3-column grid (desktop), 2-col (tablet), 1-col (mobile).
 * Compact, dense cards with hairline borders. Icons in muted containers.
 * No accent color here — this section is intentionally quiet.
 */

interface Feature {
  icon: typeof Users;
  title: string;
  description: string;
}

const features: Feature[] = [
  {
    icon: Users,
    title: "Student Management",
    description: "Enrollment, profiles, and academic history for every student.",
  },
  {
    icon: ClipboardCheck,
    title: "CBC Grading",
    description: "8-point rubric, term exams, and automated report cards.",
  },
  {
    icon: Bot,
    title: "Mwalimu AI",
    description: "AI study assistant for students — revision help, quizzes, and homework support.",
  },
  {
    icon: MessageSquare,
    title: "Class Chat",
    description: "Real-time messaging between students, teachers, and parents.",
  },
  {
    icon: CalendarCheck,
    title: "Attendance",
    description: "Daily tracking, reports, and real-time parent notifications.",
  },
  {
    icon: Calendar,
    title: "Timetable",
    description: "Build, manage, and share class schedules in minutes.",
  },
];

export function Features() {
  return (
    <section id="features" className="py-24 lg:py-32 relative border-t border-border">
      <div className="container">
        {/* Section header */}
        <div className="reveal mb-12 lg:mb-16 max-w-2xl">
          <div className="eyebrow mb-4">Features</div>
          <h2
            className="text-2xl sm:text-3xl lg:text-4xl font-medium tracking-[-0.02em] text-[var(--text-primary)]"
            style={{ fontFamily: "Geist, Inter, sans-serif" }}
          >
            Everything you need to run a school.
          </h2>
        </div>

        {/* Feature grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-px bg-border rounded-xl overflow-hidden border border-border">
          {features.map((feature, i) => (
            <div
              key={feature.title}
              className={`reveal reveal-delay-${(i % 3) + 1} group bg-[var(--surface)] p-6 lg:p-8 transition-colors hover:bg-[var(--surface-hover)]`}
            >
              <div className="flex items-center justify-center w-10 h-10 rounded-lg border border-border bg-background mb-4">
                <feature.icon size={18} className="text-[var(--text-secondary)]" />
              </div>
              <h3 className="text-base font-medium text-[var(--text-primary)] mb-2">
                {feature.title}
              </h3>
              <p className="text-sm text-[var(--text-secondary)] leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
