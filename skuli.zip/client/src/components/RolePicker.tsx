import { GraduationCap, Users, BookOpen, Building2, ArrowRight } from "lucide-react";

/**
 * Skuli Role Picker — "Who are you?" section.
 * Four cards in a 2x2 grid (desktop) or stacked (mobile).
 * Compact, dense cards with hairline borders. Hover shifts background slightly.
 * Principal card has accent CTA (Book a free demo) — the one accent moment.
 */

interface Role {
  icon: typeof GraduationCap;
  title: string;
  description: string;
  cta: string;
  accent?: boolean;
}

const roles: Role[] = [
  {
    icon: GraduationCap,
    title: "Student",
    description: "View assignments, chat with classmates, get AI study help, and track your progress.",
    cta: "Log in as Student",
  },
  {
    icon: Users,
    title: "Parent",
    description: "Track attendance, view report cards, message teachers, and stay involved.",
    cta: "Log in as Parent",
  },
  {
    icon: BookOpen,
    title: "Teacher",
    description: "Manage classes, mark attendance, enter grades, and create assignments.",
    cta: "Log in as Teacher",
  },
  {
    icon: Building2,
    title: "Principal",
    description: "Set up your school on Skuli. We handle onboarding and training — it's free.",
    cta: "Book a free demo",
    accent: true,
  },
];

export function RolePicker() {
  return (
    <section id="roles" className="py-24 lg:py-32 relative">
      <div className="container">
        {/* Section header */}
        <div className="reveal mb-12 lg:mb-16">
          <div className="eyebrow mb-4">Who are you?</div>
          <h2
            className="text-2xl sm:text-3xl lg:text-4xl font-medium tracking-[-0.02em] text-[var(--text-primary)]"
            style={{ fontFamily: "Geist, Inter, sans-serif" }}
          >
            One platform. Every role.
          </h2>
        </div>

        {/* Role cards grid */}
        <div className="grid sm:grid-cols-2 gap-4">
          {roles.map((role, i) => (
            <div
              key={role.title}
              className={`reveal reveal-delay-${i + 1} group rounded-xl border border-border bg-[var(--surface)] p-6 transition-all hover:border-[var(--border-strong)] hover:bg-[var(--surface-hover)] cursor-pointer`}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center justify-center w-10 h-10 rounded-lg border border-border bg-background">
                  <role.icon
                    size={18}
                    className={role.accent ? "text-primary" : "text-[var(--text-secondary)]"}
                  />
                </div>
                {role.accent && (
                  <span className="text-[10px] uppercase tracking-wider text-primary font-medium px-2 py-0.5 rounded-full border border-primary/20 bg-primary/10">
                    Free
                  </span>
                )}
              </div>
              <h3 className="text-base font-medium text-[var(--text-primary)] mb-2">
                {role.title}
              </h3>
              <p className="text-sm text-[var(--text-secondary)] leading-relaxed mb-5">
                {role.description}
              </p>
              <div
                className={`inline-flex items-center gap-1.5 text-sm font-medium transition-colors ${
                  role.accent
                    ? "text-primary"
                    : "text-[var(--text-secondary)] group-hover:text-[var(--text-primary)]"
                }`}
              >
                {role.cta}
                <ArrowRight size={14} className="transition-transform group-hover:translate-x-0.5" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
