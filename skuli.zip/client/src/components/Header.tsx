import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";
import { SkuliLogo } from "./SkuliLogo";

/**
 * Skuli Header — fixed nav with scroll-aware background.
 * Hairline border appears on scroll. Login links on the right.
 * Mobile: hamburger opens a sheet-style menu.
 */
export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const loginLinks = [
    { label: "Staff Login", href: "#" },
    { label: "Student Login", href: "#" },
    { label: "Parent Login", href: "#" },
  ];

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? "bg-background/80 backdrop-blur-xl border-b border-border"
            : "bg-transparent border-b border-transparent"
        }`}
      >
        <div className="container flex items-center justify-between h-16">
          <SkuliLogo />

          {/* Desktop nav */}
          <nav className="hidden md:flex items-center gap-8">
            {loginLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-sm text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors duration-200"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Mobile hamburger */}
          <button
            className="md:hidden text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </header>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div
            className="absolute inset-0 bg-background/95 backdrop-blur-xl"
            onClick={() => setMobileOpen(false)}
          />
          <div className="relative flex flex-col items-center justify-center h-full gap-8">
            {loginLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-lg text-[var(--text-primary)] hover:text-primary transition-colors"
                onClick={() => setMobileOpen(false)}
              >
                {link.label}
              </a>
            ))}
          </div>
        </div>
      )}
    </>
  );
}
