import { useParallaxTilt } from "@/hooks/useParallaxTilt";
import { useScrollParallax } from "@/hooks/useScrollParallax";
import { DashboardMockup } from "./DashboardMockup";

/**
 * Skuli Hero — asymmetric layout.
 * Text left, 3D-tilted dashboard mockup right.
 * Background grid with subtle scroll parallax.
 * Single accent CTA — the only accent-colored element on screen.
 */
export function Hero() {
  const { ref: tiltRef, tilt } = useParallaxTilt(8);
  const parallaxOffset = useScrollParallax(0.15);

  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background grid with parallax */}
      <div
        className="absolute inset-0 grid-bg opacity-60"
        style={{ transform: `translateY(${parallaxOffset}px)` }}
      />
      {/* Radial fade mask */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse 80% 50% at 50% 0%, rgba(125, 211, 252, 0.06), transparent)",
        }}
      />

      <div className="container relative z-10">
        <div className="grid lg:grid-cols-[1.1fr_1fr] gap-12 lg:gap-16 items-center">
          {/* Left: text */}
          <div className="reveal">
            <div className="eyebrow mb-6">
              Built for CBC · Free onboarding
            </div>
            <h1
              className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-semibold tracking-[-0.02em] leading-[1.05] text-[var(--text-primary)]"
              style={{ fontFamily: "Geist, Inter, sans-serif" }}
            >
              The operating system for Kenyan schools
            </h1>
            <p className="mt-6 text-base lg:text-lg text-[var(--text-secondary)] leading-relaxed max-w-xl">
              Attendance, grades, timetables, and parent communication — in one place. Built for CBC. Free onboarding.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row gap-3">
              <a
                href="#roles"
                className="inline-flex items-center justify-center h-11 px-6 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-all hover:scale-[0.98] active:scale-[0.97] accent-glow"
              >
                Book a free demo
              </a>
              <a
                href="#features"
                className="inline-flex items-center justify-center h-11 px-6 rounded-lg border border-[var(--border-strong)] text-[var(--text-primary)] text-sm font-medium hover:bg-[var(--surface-hover)] transition-all"
              >
                Explore features
              </a>
            </div>
          </div>

          {/* Right: 3D tilted mockup */}
          <div className="reveal reveal-delay-2 hidden lg:block">
            <div
              ref={tiltRef}
              className="relative"
              style={{
                transform: `perspective(1200px) rotateX(${tilt.rotateX}deg) rotateY(${tilt.rotateY}deg)`,
                transformStyle: "preserve-3d",
                transition: "transform 0.1s ease-out",
              }}
            >
              {/* Glow behind mockup */}
              <div
                className="absolute -inset-4 rounded-2xl"
                style={{
                  background:
                    "radial-gradient(ellipse at center, rgba(125, 211, 252, 0.08), transparent 70%)",
                }}
              />
              <div className="relative aspect-[4/3] w-full max-w-lg ml-auto">
                <DashboardMockup />
              </div>
            </div>
          </div>

          {/* Mobile: static mockup */}
          <div className="reveal reveal-delay-2 lg:hidden">
            <div className="aspect-[4/3] w-full max-w-sm mx-auto">
              <DashboardMockup />
            </div>
          </div>
        </div>
      </div>

      {/* Bottom fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent pointer-events-none" />
    </section>
  );
}
