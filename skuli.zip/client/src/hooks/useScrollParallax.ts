import { useEffect, useState } from "react";

/**
 * Skuli scroll-linked parallax hook.
 * Returns a translateY value based on scroll position relative to viewport.
 * Used for background grid lines and dot patterns that move at a different rate
 * than foreground content, creating depth without 3D rendering.
 */
export function useScrollParallax(speed: number = 0.3) {
  const [offset, setOffset] = useState(0);

  useEffect(() => {
    const prefersReduced = window.matchMedia(
      "(prefers-reduced-motion: reduce)"
    ).matches;
    if (prefersReduced) return;

    let rafId = 0;

    const handleScroll = () => {
      cancelAnimationFrame(rafId);
      rafId = requestAnimationFrame(() => {
        setOffset(window.scrollY * speed);
      });
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", handleScroll);
      cancelAnimationFrame(rafId);
    };
  }, [speed]);

  return offset;
}
