import { Header } from "@/components/Header";
import { Hero } from "@/components/Hero";
import { RolePicker } from "@/components/RolePicker";
import { Features } from "@/components/Features";
import { CTASection } from "@/components/CTASection";
import { Footer } from "@/components/Footer";
import { useScrollReveal } from "@/hooks/useScrollReveal";

/**
 * Skuli Homepage — full marketing page.
 * Header → Hero (3D mockup) → Role Picker → Features → CTA → Footer
 * Dark-mode-first, Resend-inspired, light cyan-blue accent.
 */
export default function Home() {
  const containerRef = useScrollReveal<HTMLDivElement>();

  return (
    <div ref={containerRef} className="min-h-screen bg-[--background]">
      <Header />
      <main>
        <Hero />
        <RolePicker />
        <Features />
        <CTASection />
      </main>
      <Footer />
    </div>
  );
}
