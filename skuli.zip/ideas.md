# Skuli — Design Brainstorm

## Three Stylistic Approaches

### 1. Quiet Precision (Resend-faithful)
**Theme Name:** Quiet Precision
**Brief:** Disciplined monochrome dark interface with hairline borders, one accent, and a single 3D tilt moment. Premium software feel — borders over shadows, typography over decoration.
**Probability:** 0.07

### 2. Warm Editorial
**Theme Name:** Warm Editorial
**Brief:** Dark base with warm paper-like card surfaces, serif headlines mixed with grotesk body, generous editorial whitespace. Feels like a digital yearbook.
**Probability:** 0.04

### 3. Kenyan Signal
**Theme Name:** Kenyan Signal
**Brief:** Dark mode with a single warm accent inspired by Kenyan sunset tones, bold geometric patterns as subtle background texture, and a confident civic-poster typographic voice.
**Probability:** 0.03

---

## Chosen Approach: Quiet Precision

**Design Movement:** Resend-inspired dark-mode-first software aesthetic — restrained, precise, premium.

**Core Principles:**
1. Restraint over decoration — remove more than you add
2. One accent (light cyan-blue) used sparingly — only on the single most important interactive element per screen
3. Borders over shadows — 1px hairlines define everything
4. Typography carries hierarchy — weight and letter-spacing do the heavy lifting, not size jumps

**Color Philosophy:** Near-black background (#0A0A0A) with elevated surfaces at #111–#141. Text in pure white through to 40% opacity white for tertiary content. The accent — light cyan-blue (#7DD3FC) — appears only on primary CTAs, active nav states, and key data highlights. It should feel like a signal in the dark, not a decoration. Status colors are desaturated and quiet.

**Layout Paradigm:** Asymmetric hero (text left, 3D mockup right) breaking the centered-template reflex. Generous vertical breathing room (96–160px between sections) contrasted with compact, dense card components. 12-column underlying grid for marketing sections.

**Signature Elements:**
1. Hairline borders (rgba(255,255,255,0.08–0.12)) on every card, panel, and divider — never box-shadows
2. Small uppercase eyebrow labels with positive letter-spacing above section headlines
3. A single 3D-tilted dashboard mockup in the hero that responds to mouse movement (max 6–8° parallax tilt)

**Interaction Philosophy:** Motion is a whisper. Scroll reveals are small opacity + translateY fades. Hover states are subtle background shifts, not transforms. The 3D tilt is the one "wow" moment — used once, on the hero.

**Animation:** Scroll-triggered fades (translateY 20px → 0, opacity 0 → 1, 400ms ease-out). Staggered children by 60–80ms. Hero mockup parallax tilt on mousemove (max 8°, smooth lerp). Background grid lines with subtle scroll-linked parallax. All gated behind prefers-reduced-motion.

**Typography System:** Geist (Vercel's grotesk) as the sole typeface. Hero: 56–72px, weight 600, -0.02em tracking, 1.05 line-height. Section: 32–40px, weight 500. Card title: 16–18px, weight 500. Body: 14–16px, weight 400, 1.6 line-height. Caption: 12–13px, weight 400. Eyebrows: 12px uppercase, 0.08em tracking, tertiary color.

**Brand Essence:** Skuli is the operating system for Kenyan schools — calm, precise, and trustworthy software for education administrators, teachers, parents, and students.

**Brand Voice:** Direct, confident, understated. No exclamation marks. No "welcome to." Examples: "The operating system for Kenyan schools." / "Attendance, grades, timetables, and parent communication — in one place."

**Wordmark & Logo:** "Skuli" set in Geist 600 with tight tracking (-0.03em), paired with a small geometric mark — a rounded square with a subtle inner notch suggesting a school building silhouette. The mark uses the accent color at low opacity.

**Signature Brand Color:** #7DD3FC — light cyan-blue. Clean, digital, calm. Distinct from the typical blue/purple SaaS palette while remaining professional.
